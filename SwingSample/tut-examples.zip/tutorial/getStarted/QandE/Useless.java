/* Well, maybe this isn't completely useless. */

/* This program uses API introduced in 1.1. */

public class Useless {
    public static void main(String[] args) {
        System.out.println(java.util.Locale.getDefault());
    }
}

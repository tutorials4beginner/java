public class InputFileTest {
    public static void main(String[] args) throws java.io.IOException {
        InputFileDeclared file = new InputFileDeclared("testing");
        System.out.println(file.getWord());
        System.out.println(file.getWord());
        System.out.println(file.getWord());
    }
}

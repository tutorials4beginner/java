import java.io.*;

public class PrintStuff {
    public static void main(String[] args) throws IOException {
        System.out.println(! false);                //boolean
        System.out.println('3');                    //char
        char three[] = {'t', 'h', 'r', 'e', 'e'};
        System.out.println(three);                  //char []
        System.out.println("Three");                //String
        System.out.println(3);                      //int
        System.out.println(Long.MAX_VALUE);
        System.out.println(Math.PI);
        System.out.println(Double.MAX_VALUE);
        System.out.println(new Object());
    }
}

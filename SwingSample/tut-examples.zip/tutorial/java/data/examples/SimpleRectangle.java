public class SimpleRectangle {
    public int width = 0;
    public int height = 0;
    public SimplePoint origin = new SimplePoint();
}

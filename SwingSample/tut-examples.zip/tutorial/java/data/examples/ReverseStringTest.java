public class ReverseStringTest {
    public static void main(String[] args) {
        String str = "What's going on?";
        System.out.println(ReverseString.reverseIt(str));
    }
}

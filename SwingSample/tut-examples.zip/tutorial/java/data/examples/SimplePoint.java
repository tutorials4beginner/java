public class SimplePoint {
    public int x = 0;
    public int y = 0;
}

public class ArrayOfStringsDemo {
    public static void main(String[] args) {
        String[] anArray = { "String One", 
                             "String Two", 
                             "String Three" };

        for (String s: anArray) {
            System.out.println(s.toLowerCase());
        }
    }
}

public class Problem {
	String s;
	static class Inner {
		void testMethod() {
		   s = "Set from Inner";
		}
	}
}


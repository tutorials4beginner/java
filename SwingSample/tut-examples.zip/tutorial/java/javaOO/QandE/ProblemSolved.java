public class ProblemSolved {
	String s;
	class Inner {
		void testMethod() {
		   s = "Set from Inner";
		}
	}
}


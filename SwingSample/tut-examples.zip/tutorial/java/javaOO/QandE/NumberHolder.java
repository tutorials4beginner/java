public class NumberHolder {
    public int anInt;
    public float aFloat;
}

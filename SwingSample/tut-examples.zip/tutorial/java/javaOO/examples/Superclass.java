public class Superclass {
    public boolean aVariable;

    public void aMethod() {
        aVariable = true;
    }
}
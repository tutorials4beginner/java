class AlienCreatureTwo extends AlienCreature {
    String live(){
        String living="We alien twos live happily on alien two nutrition.";
        return living;
    }
} 


//nonabstract subclass 1
class AlienCreatureOne extends AlienCreature {
    String live(){
        String living="We alien ones live happily on alien one nutrition.";
        return living;
    }
}
//nonabstract subclass 2

/* 
 * Java(TM) SE 6
 * Code is the same as 1.0.
 */

class QuoteServer {
    public static void main(String[] args) {
        new QuoteServerThread().start();
    }
}

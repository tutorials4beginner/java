/* 
 * If this were a real example, this file would have source
 * code compatible with the JDK 1.0.2 release.
 */
